package com.example.weatherforecast;

import com.example.weatherforecast.model.AllResultModel;
import com.example.weatherforecast.model.LivesResultModel;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

public interface WeatherService {
    @GET("v3/weather/weatherInfo")
    Call<LivesResultModel> getLiveData(@QueryMap Map<String, String> params);
    @GET("v3/weather/weatherInfo")
    Call<AllResultModel> getAllData(@QueryMap Map<String, String> params);
}
