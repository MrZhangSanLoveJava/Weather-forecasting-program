package com.example.weatherforecast.data;

public class Weather {
    private String tomorrowTitle;
    private String tomorrowDayWeatherText;
    private String tomorrownightweatherText;
    private String tomorrowDayTempText;
    private String tomorrownighttempText;

    public Weather(String tomorrowTitle, String tomorrowDayWeatherText, String tomorrownightweatherText, String tomorrowDayTempText, String tomorrownighttempText) {
        this.tomorrowTitle = tomorrowTitle;
        this.tomorrowDayWeatherText = tomorrowDayWeatherText;
        this.tomorrownightweatherText = tomorrownightweatherText;
        this.tomorrowDayTempText = tomorrowDayTempText;
        this.tomorrownighttempText = tomorrownighttempText;
    }

    public String getTomorrowTitle() {
        return tomorrowTitle;
    }

    public void setTomorrowTitle(String tomorrowTitle) {
        this.tomorrowTitle = tomorrowTitle;
    }

    public String getTomorrowDayWeatherText() {
        return tomorrowDayWeatherText;
    }

    public void setTomorrowDayWeatherText(String tomorrowDayWeatherText) {
        this.tomorrowDayWeatherText = tomorrowDayWeatherText;
    }

    public String getTomorrownightweatherText() {
        return tomorrownightweatherText;
    }

    public void setTomorrownightweatherText(String tomorrownightweatherText) {
        this.tomorrownightweatherText = tomorrownightweatherText;
    }

    public String getTomorrowDayTempText() {
        return tomorrowDayTempText;
    }

    public void setTomorrowDayTempText(String tomorrowDayTempText) {
        this.tomorrowDayTempText = tomorrowDayTempText;
    }

    public String getTomorrownighttempText() {
        return tomorrownighttempText;
    }

    public void setTomorrownighttempText(String tomorrownighttempText) {
        this.tomorrownighttempText = tomorrownighttempText;
    }
}
