package com.example.weatherforecast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.weatherforecast.data.Weather;
import com.example.weatherforecast.model.AllResultModel;
import com.example.weatherforecast.model.LivesResultModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Weather> weathers = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }
    private void initView(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://restapi.amap.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        WeatherService weatherService = retrofit.create(WeatherService.class);
        Map<String, String> params = new HashMap<>();
        params.put("key", "a7c9048f689985d4db02f0d2218806f0");
        params.put("city", "北京");
        params.put("extensions", "all");
        Call<AllResultModel> allResultModelCall = weatherService.getAllData(params);
        allResultModelCall.enqueue(new Callback<AllResultModel>() {
            @Override
            public void onResponse(Call<AllResultModel> call, Response<AllResultModel> response) {
                AllResultModel live = response.body();
                if (live != null){
                    if ("1".equals(live.getStatus())){
                        ArrayList<AllResultModel.ForecastsBean> allBeanArrayList = (ArrayList<AllResultModel.ForecastsBean>) live.getForecasts();
                        if (allBeanArrayList != null && allBeanArrayList.size() != 0){
                            AllResultModel.ForecastsBean current = allBeanArrayList.get(0);
                            List<AllResultModel.ForecastsBean.CastsBean> castsBeans = current.getCasts();
                            if (current != null){
                                TextView title = findViewById(R.id.title);
                                title.setText(current.getCity());
                                weathers.add(new Weather("今天", castsBeans.get(0).getDayweather(), castsBeans.get(0).getNightweather(), castsBeans.get(0).getDaytemp(), castsBeans.get(0).getNighttemp()));
                                weathers.add(new Weather("明天", castsBeans.get(1).getDayweather(), castsBeans.get(1).getNightweather(), castsBeans.get(1).getDaytemp(), castsBeans.get(1).getNighttemp()));
                                weathers.add(new Weather("后天", castsBeans.get(2).getDayweather(), castsBeans.get(2).getNightweather(), castsBeans.get(2).getDaytemp(), castsBeans.get(2).getNighttemp()));
                                weathers.add(new Weather("再后天", castsBeans.get(3).getDayweather(), castsBeans.get(3).getNightweather(), castsBeans.get(3).getDaytemp(), castsBeans.get(3).getNighttemp()));
                                RecyclerView.LayoutManager layoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL);
                                RecyclerView recyclerView = findViewById(R.id.weatherAll);
                                recyclerView.setLayoutManager(layoutManager);
                                recyclerView.setAdapter(new WeatherAdapter());
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<AllResultModel> call, Throwable t) {

            }
        });
    }
    //创建Weather的把手
    class WeatherViewHolder extends RecyclerView.ViewHolder {
        private TextView tomorrowTitle;
        private TextView tomorrowDayWeatherText;
        private TextView tomorrownightweatherText;
        private TextView tomorrowDayTempText;
        private TextView tomorrownighttempText;

        public WeatherViewHolder(View view) {
            super(view);
            this.tomorrowTitle = view.findViewById(R.id.tomorrowTitle);
            this.tomorrowDayWeatherText = view.findViewById(R.id.tomorrowDayWeatherText);
            this.tomorrownightweatherText = view.findViewById(R.id.tomorrownightweatherText);
            this.tomorrowDayTempText = view.findViewById(R.id.tomorrowDayTempText);
            this.tomorrownighttempText = view.findViewById(R.id.tomorrownighttempText);
        }
    }
    //创建Weather的适配器
    class WeatherAdapter extends RecyclerView.Adapter {

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = getLayoutInflater().inflate(R.layout.weath, parent, false);

            return new WeatherViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            Weather weather = weathers.get(position);
            WeatherViewHolder weatherViewHolder = (WeatherViewHolder) holder;
            weatherViewHolder.tomorrowTitle.setText(weather.getTomorrowTitle());
            weatherViewHolder.tomorrowDayWeatherText.setText(weather.getTomorrowDayWeatherText());
            weatherViewHolder.tomorrownightweatherText.setText(weather.getTomorrownightweatherText());
            weatherViewHolder.tomorrowDayTempText.setText(weather.getTomorrowDayTempText());
            weatherViewHolder.tomorrownighttempText.setText(weather.getTomorrownighttempText());

        }

        @Override
        public int getItemCount() {
            return 4;
        }
    }
}